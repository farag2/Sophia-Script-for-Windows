﻿# Remove "Edit" from images context menu
#! Do not modify this string
# Удалить пункт "Изменить" из контекстного меню изображений
#! Не изменяйте эту строку
if ((Get-WindowsCapability -Online -Name "Microsoft.Windows.MSPaint*").State -eq "Installed")
{
	New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\image\shell\edit -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force
}
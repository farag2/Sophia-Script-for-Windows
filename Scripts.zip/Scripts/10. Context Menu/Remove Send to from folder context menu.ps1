﻿# Remove "Send to" from folder context menu
#! Do not modify this string
# Удалить пункт "Отправить" из контекстного меню папки
#! Не изменяйте эту строку
New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo -Name "(default)" -PropertyType String -Value "" -Force
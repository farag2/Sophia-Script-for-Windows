﻿# Turn off "Look for an app in the Microsoft Store" in "Open with" dialog
# After turning off, no search for applications in the Microsoft Store will be offered for unregistered extensions
# Отключить "Поиск приложения в Microsoft Store" в диалоге "Открыть с помощью"
# После отключения для незарегистрированных расширений не будет предлагаться поиск приложения в Microsoft Store
New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name NoUseStoreOpenWith -PropertyType DWord -Value 1 -Force
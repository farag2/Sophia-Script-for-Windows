﻿# Turn off Xbox Game Bar
# Xbox Game Bar is for thigs like recording game clips, chatting with friends, receiving game invites
# Отключить Xbox Game Bar
# Xbox Game Bar позволяет создавать игровые клипы, общаться с друщьями и получать приглашения в игры
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR -Name AppCaptureEnabled -PropertyType DWord -Value 0 -Force
New-ItemProperty -Path HKCU:\System\GameConfigStore -Name GameDVR_Enabled -PropertyType DWord -Value 0 -Force
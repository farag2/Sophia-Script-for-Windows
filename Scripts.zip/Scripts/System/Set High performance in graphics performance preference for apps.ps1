﻿# Set "High performance" in graphics performance preference for apps
#! Do not modify this string
# Установить параметры производительности графики для отдельных приложений на "Высокая производительность"
#! Не изменяйте эту строку
Start-Process -FilePath ms-settings:display-advancedgraphics
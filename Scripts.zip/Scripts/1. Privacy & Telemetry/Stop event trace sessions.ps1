﻿# Stop event trace sessions
#! Do not modify this string
# Остановить сеансы отслеживания событий
#! Не изменяйте эту строку
Get-EtwTraceSession -Name DiagLog -ErrorAction Ignore | Remove-EtwTraceSession
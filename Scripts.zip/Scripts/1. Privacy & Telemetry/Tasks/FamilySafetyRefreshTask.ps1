﻿# Synchronizes the latest settings with the Microsoft family features service
# Синхронизирует последние параметры со службой функций семьи учетных записей Майкрософт
Get-ScheduledTask -TaskName "FamilySafetyRefreshTask" | Disable-ScheduledTask
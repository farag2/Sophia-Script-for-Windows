﻿# Turn off diagnostics tracking scheduled tasks
# Tasks to be disabled: Microsoft Compatibility Appraiser, ProgramDataUpdater, Proxy, Consolidator, UsbCeip, Microsoft-Windows-DiskDiagnosticDataCollector, File History (maintenance mode), FODCleanupTask, WinSAT, MapsToastTask, MapsUpdateTask, FamilySafetyMonitor, FamilySafetyRefreshTask, QueueReporting, XblGameSaveTask

# Отключить задачи диагностического отслеживания
# Будут отключены: Microsoft Compatibility Appraiser, ProgramDataUpdater, Proxy, Consolidator, UsbCeip, Microsoft-Windows-DiskDiagnosticDataCollector, File History (maintenance mode), FODCleanupTask, WinSAT, MapsToastTask, MapsUpdateTask, FamilySafetyMonitor, FamilySafetyRefreshTask, QueueReporting, XblGameSaveTask

# Collects program telemetry information if opted-in to the Microsoft Customer Experience Improvement Program.
# Собирает телеметрические данные программы при участии в Программе улучшения качества программного обеспечения Майкрософт
Get-ScheduledTask -TaskName "Microsoft Compatibility Appraiser" | Disable-ScheduledTask
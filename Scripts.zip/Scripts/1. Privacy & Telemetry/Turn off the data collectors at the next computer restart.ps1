﻿# Turn off the data collectors at the next computer restart
#! Do not modify this string
# Отключить сборщики данных при следующем запуске ПК
#! Не изменяйте эту строку
Update-AutologgerConfig -Name DiagLog, Diagtrack-Listener -Start 0
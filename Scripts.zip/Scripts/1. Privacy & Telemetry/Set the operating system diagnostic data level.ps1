﻿# Set the operating system diagnostic data level
#! Do not modify this string
# Установить уровень отправляемых диагностических сведений
#! Не изменяйте эту строку
if ((Get-WindowsEdition -Online).Edition -eq "Enterprise" -or (Get-WindowsEdition -Online).Edition -eq "Education")
{
	# "Security"
	#! Do not modify this string
	# "Безопасность"
	#! Не изменяйте эту строку
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 0 -Force
}
else
{
	# "Basic"
	#! Do not modify this string
	# "Базовый"
	#! Не изменяйте эту строку
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 1 -Force
}
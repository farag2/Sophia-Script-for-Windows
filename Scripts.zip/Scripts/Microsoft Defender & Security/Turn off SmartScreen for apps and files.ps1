﻿# Turn off SmartScreen for apps and files
# Microsoft Defender SmartScreen helps protect your device by checking for unrecognized apps and fiels from the web
# Отключить SmartScreen для приложений и файлов
# Фильтр SmartScreen в Microsoft Defender помогает защитить устройство, проверяя неопознаные приложения и файлы в Интернете
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name SmartScreenEnabled -PropertyType String -Value Off -Force
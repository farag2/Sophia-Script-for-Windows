﻿# Turn off JPEG desktop wallpaper import quality reduction
#! Do not modify this string
# Отключить снижение качества фона рабочего стола в формате JPEG
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name JPEGImportQuality -PropertyType DWord -Value 100 -Force
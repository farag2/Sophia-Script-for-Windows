﻿# Turn off the "- Shortcut" name extension for new shortcuts
#! Do not modify this string
# Нe дoбaвлять "- яpлык" для coздaвaeмыx яpлыкoв
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name link -PropertyType Binary -Value ([byte[]](00, 00, 00, 00)) -Force
﻿# Show hidden files, folders, and drives
#! Do not modify this string
# Показывать скрытые файлы, папки и диски
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Hidden -PropertyType DWord -Value 1 -Force
﻿# Turn off Windows Script Host
#! Do not modify this string
# Отключить Windows Script Host
#! Не изменяйте эту строку
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings" -Name Enabled -PropertyType DWord -Value 0 -Force
﻿# Run Microsoft Defender within a sandbox
# Running Microsoft Defender Antivirus in a sandbox ensures that in the event of a compromise, malicious actions are limited to the isolated environment, protecting the rest of the system from harm
# Запускать Microsoft Defender в песочнице
# Запуск Microsoft Defender в песочнице гарантирует, что в случае компрометации вредоносные действия будут ограничены изолированной средой, защищая остальную часть системы от повреждений
setx /M MP_FORCE_USE_SANDBOX 1
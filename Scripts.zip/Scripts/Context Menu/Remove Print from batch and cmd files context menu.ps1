﻿# Remove "Print" from batch and .cmd files context menu
#! Do not modify this string
# Удалить пункт "Печать" из контекстного меню пакетных и .cmd файлов
#! Не изменяйте эту строку
New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\batfile\shell\print -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force
New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\cmdfile\shell\print -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force
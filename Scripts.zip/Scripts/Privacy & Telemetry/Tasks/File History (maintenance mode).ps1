﻿# Protects user files from accidental loss by copying them to a backup location when the system is unattended
# Защищает файлы пользователя от случайной потери за счет их копирования в резервное расположение, когда система находится в автоматическом режиме
Get-ScheduledTask -TaskName "File History (maintenance mode)" | Disable-ScheduledTask
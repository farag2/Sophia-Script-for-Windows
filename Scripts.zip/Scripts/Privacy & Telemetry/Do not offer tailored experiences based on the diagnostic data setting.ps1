﻿# Do not offer tailored experiences based on the diagnostic data setting
# Let Microsoft use your diagnostic data, excluding information about websites you browse, to offer you personalized tips, ads, and recommedations to enhance your Microsoft experiences
# Не предлагать персонализированные возможности, основанные на выбранном параметре диагностических данных
# Индивидуальные возможности — это персонализированные советы, рекламные объявления и рекомендации, которые улучшают продукты и услуги Microfost с учетом ваших нужд
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy -Name TailoredExperiencesWithDiagnosticDataEnabled -PropertyType DWord -Value 0 -Force
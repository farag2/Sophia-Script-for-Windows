﻿# Turn off per-user services
#! Do not modify this string
# Отключить пользовательские службы
#! Не изменяйте эту строку
$services = @(
	# Contact Data
	#! Do not modify this string
	# Служба контактных данных
	#! Не изменяйте эту строку
	"PimIndexMaintenanceSvc_*"
	# User Data Storage
	#! Do not modify this string
	# Служба хранения данных пользователя
	#! Не изменяйте эту строку
	"UnistoreSvc_*"
	# User Data Access
	#! Do not modify this string
	# Служба доступа к данным пользователя
	#! Не изменяйте эту строку
	"UserDataSvc_*"
)
Get-Service -Name $services | Stop-Service -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\PimIndexMaintenanceSvc -Name Start -PropertyType DWord -Value 4 -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\PimIndexMaintenanceSvc -Name UserServiceFlags -PropertyType DWord -Value 0 -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\UnistoreSvc -Name Start -PropertyType DWord -Value 4 -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\UnistoreSvc -Name UserServiceFlags -PropertyType DWord -Value 0 -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\UserDataSvc -Name Start -PropertyType DWord -Value 4 -Force
New-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\UserDataSvc -Name UserServiceFlags -PropertyType DWord -Value 0 -Force
﻿# Use the PrtScn button to open screen snipping
#! Do not modify this string
# Использовать кнопку PRINT SCREEN, чтобы запустить функцию создания фрагмента экрана
#! Не изменяйте эту строку
New-ItemProperty -Path "HKCU:\Control Panel\Keyboard" -Name PrintScreenKeyForSnippingEnabled -PropertyType DWord -Value 1 -Force
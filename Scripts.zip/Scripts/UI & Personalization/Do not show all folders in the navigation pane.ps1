﻿# Do not show all folders in the navigation pane
#! Do not modify this string
# Не отображать все папки в области навигации
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name NavPaneShowAllFolders -PropertyType DWord -Value 0 -Force
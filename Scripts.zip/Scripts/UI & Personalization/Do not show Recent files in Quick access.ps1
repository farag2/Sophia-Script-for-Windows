﻿# Do not show "Recent files" in Quick access
#! Do not modify this string
# Не показывать недавно использовавшиеся файлы на панели быстрого доступа
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer -Name ShowRecent -PropertyType DWord -Value 0 -Force
﻿# Turn off AutoPlay for all media and devices
#! Do not modify this string
#! Не изменяйте эту строку
# Отключить автозапуск для всех носителей и устройств
#! Do not modify this string
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers -Name DisableAutoplay -PropertyType DWord -Value 1 -Force
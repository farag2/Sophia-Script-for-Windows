﻿# Turn on updates for other Microsoft products
#! Do not modify this string
# Включить автоматическое обновление для других продуктов Microsoft
#! Не изменяйте эту строку
(New-Object -ComObject Microsoft.Update.ServiceManager).AddService2("7971f918-a847-4430-9279-4a52d1efe18d", 7, "")
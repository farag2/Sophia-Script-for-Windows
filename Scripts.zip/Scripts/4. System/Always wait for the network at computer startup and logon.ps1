﻿# Always wait for the network at computer startup and logon
# Windows waits for complete network initialization before users are logged on. This results in the synchronous application of policies when the computer starts and when the user logs on
# Всегда ждать сеть при запуске и входе в систему
# Windows ожидает полной инициализации сети, прежде чем пользователи войдут в систему. Это приводит к синхронному применению политик при запуске компьютера и при входе пользователя в систему
IF (-not (Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Winlogon"))
{
	New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Winlogon" -Force
}
New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name SyncForegroundPolicy -PropertyType DWord -Value 1 -Force
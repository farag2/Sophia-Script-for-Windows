﻿# Turn off location for this device
#! Do not modify this string
# Отключить местоположение для этого устройства
#! Не изменяйте эту строку
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location -Name Value -PropertyType String -Value Deny -Force
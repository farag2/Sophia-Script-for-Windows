﻿# Set the default input method to the English language
#! Do not modify this string
# Установить метод ввода по умолчанию на английский язык
#! Не изменяйте эту строку
Set-WinDefaultInputMethodOverride "0409:00000409"
﻿# Delete files in recycle bin if they have been there for over 30 days
#! Do not modify this string
# Удалять файлы, которые находятся в корзине более 30 дней
#! Не изменяйте эту строку
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 256 -PropertyType DWord -Value 30 -Force
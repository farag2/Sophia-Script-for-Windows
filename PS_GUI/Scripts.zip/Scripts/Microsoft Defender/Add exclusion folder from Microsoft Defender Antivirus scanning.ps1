﻿# Add exclusion folder from Microsoft Defender Antivirus scanning
# Добавить папку в список исключений сканирования Защитника Windows
function ExclusionPath
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $True)]
		[string[]]$paths
	)
	$paths = $paths.Replace("`"", "").Split(",").Trim()
	Add-MpPreference -ExclusionPath $paths -Force
}
ExclusionPath $paths
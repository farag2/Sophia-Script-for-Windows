﻿# Turn on Microsoft Defender PUA Protection
# Включить блокировки потенциально нежелательных приложений
Set-MpPreference -PUAProtection Enabled
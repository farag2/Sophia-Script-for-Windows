﻿# Allow an app through Controlled folder access
# Разрешить работу приложения через контролируемый доступ к папкам
IF ((Get-MpPreference).EnableControlledFolderAccess -eq 1)
{
	function ControlledFolderAllowedApplications
	{
		[CmdletBinding()]
		Param
		(
			[Parameter(Mandatory = $True)]
			[string[]]$paths
		)
		$paths = $paths.Replace("`"", "").Split(",").Trim()
		Add-MpPreference -ControlledFolderAccessAllowedApplications $paths
	}
	ControlledFolderAllowedApplications $paths
}
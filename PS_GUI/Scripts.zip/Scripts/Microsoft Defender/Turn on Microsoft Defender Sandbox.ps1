﻿# Turn on Microsoft Defender Sandbox
# Запускать Защитник Windows в песочнице
setx /M MP_FORCE_USE_SANDBOX 1
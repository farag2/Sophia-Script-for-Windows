﻿# Stop event trace sessions
# Остановить сеансы отслеживания событий
Get-EtwTraceSession -Name DiagLog -ErrorAction Ignore | Remove-EtwTraceSession
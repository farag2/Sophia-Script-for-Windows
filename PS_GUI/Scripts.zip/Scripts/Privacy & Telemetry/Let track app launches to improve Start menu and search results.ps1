﻿# Let Windows track app launches to improve Start menu and search results
# Разрешить Windows отслеживать запуски приложений для улучшения меню "Пуск" и результатов поиска
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced -Name Start_TrackProgs -PropertyType DWord -Value 1 -Force